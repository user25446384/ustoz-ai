import type { Metadata } from 'next';
import { DashboardView } from '@/features/dashboard/dashboard-view';

export const metadata: Metadata = { title: 'Bosh sahifa' };

export default function Page() {
  return <DashboardView />;
}
